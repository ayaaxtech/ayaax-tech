import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";
import { transcribeAudio } from "./_core/voiceTranscription";
import { getDb } from "./db";
import { chats, messages, agents, users } from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  chat: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(chats)
        .where(and(eq(chats.userId, ctx.user.id), eq(chats.isHidden, false)))
        .orderBy(desc(chats.updatedAt))
        .limit(100);
    }),

    create: protectedProcedure
      .input(z.object({ mode: z.string().default("tsunami"), title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const result = await db.insert(chats).values({
          userId: ctx.user.id,
          title: input.title || "New Chat",
          mode: input.mode,
        });
        return { id: Number(result[0].insertId) };
      }),

    delete: protectedProcedure
      .input(z.object({ chatId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.delete(messages).where(eq(messages.chatId, input.chatId));
        await db.delete(agents).where(eq(agents.chatId, input.chatId));
        await db.delete(chats).where(and(eq(chats.id, input.chatId), eq(chats.userId, ctx.user.id)));
        return { success: true };
      }),

    hide: protectedProcedure
      .input(z.object({ chatId: z.number(), hidden: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(chats).set({ isHidden: input.hidden })
          .where(and(eq(chats.id, input.chatId), eq(chats.userId, ctx.user.id)));
        return { success: true };
      }),

    getMessages: protectedProcedure
      .input(z.object({ chatId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(messages)
          .where(eq(messages.chatId, input.chatId))
          .orderBy(messages.createdAt);
      }),

    updateTitle: protectedProcedure
      .input(z.object({ chatId: z.number(), title: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(chats).set({ title: input.title })
          .where(and(eq(chats.id, input.chatId), eq(chats.userId, ctx.user.id)));
        return { success: true };
      }),
  }),

  ai: router({
    // Beast Mode: advanced code and full app generation
    beast: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        message: z.string(),
        history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const history = input.history || [];
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Ayaax Beast Mode — an elite AI software engineer capable of generating complete, production-ready applications, advanced algorithms, full-stack code, and complex technical solutions. You write clean, well-commented, efficient code. When asked to build an app, provide the complete file structure, all necessary code files, and clear setup instructions. You are powerful, precise, and comprehensive.`,
            },
            ...history,
            { role: "user", content: input.message },
          ],
        });
        const rawContent = response.choices[0]?.message?.content;
        const content = typeof rawContent === "string" ? rawContent : (rawContent as any[])?.[0]?.text || "";
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{ chatId: input.chatId, role: "user" as const, content: input.message }]);
            await db.insert(messages).values([{ chatId: input.chatId, role: "assistant" as const, content }]);
          }
        }
        return { content };
      }),

    // Tsunami 2.0 Chat: everyday conversational AI
    tsunami: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        message: z.string(),
        history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const history = input.history || [];
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Ayaax Tsunami 2.0 — a warm, intelligent, and highly capable everyday conversational AI. You are Ayaax's upgraded daily assistant. You help with anything from casual conversation to complex questions, creative writing, advice, explanations, and more. You are friendly, empathetic, knowledgeable, and always ready to help. Respond naturally and engagingly.`,
            },
            ...history,
            { role: "user", content: input.message },
          ],
        });
        const rawContent2 = response.choices[0]?.message?.content;
        const content = typeof rawContent2 === "string" ? rawContent2 : (rawContent2 as any[])?.[0]?.text || "";
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{ chatId: input.chatId, role: "user" as const, content: input.message }]);
            await db.insert(messages).values([{ chatId: input.chatId, role: "assistant" as const, content }]);
          }
        }
        return { content };
      }),

    // Deep-Gap Mode: visible thinking before responding
    deepgap: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        message: z.string(),
        history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const history = input.history || [];
        const thinkResponse = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Ayaax Deep-Gap Mode. First, think deeply and carefully about the user's message. Output your internal reasoning and thought process in a <thinking> block. Then provide your final, well-reasoned response after the thinking block. Format: <thinking>your step-by-step reasoning here</thinking>\n\nYour final response here.`,
            },
            ...history,
            { role: "user", content: input.message },
          ],
        });
        const rawContent3 = thinkResponse.choices[0]?.message?.content;
        const content = typeof rawContent3 === "string" ? rawContent3 : (rawContent3 as any[])?.[0]?.text || "";
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{ chatId: input.chatId, role: "user" as const, content: input.message }]);
            await db.insert(messages).values([{ chatId: input.chatId, role: "assistant" as const, content }]);
          }
        }
        return { content };
      }),

    // Analyst Mode: research with sources
    analyst: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        message: z.string(),
        history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const history = input.history || [];
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Ayaax Analyst Mode — a thorough research AI. When given a topic, you research it deeply and provide comprehensive analysis. Always include relevant sources and references in your response. Format your response with:
1. A clear executive summary
2. Detailed analysis with sections
3. Key findings and insights
4. Sources section at the end with clickable markdown links formatted as [Source Title](https://example.com)

Provide real, credible sources when possible. Be thorough, accurate, and insightful.`,
            },
            ...history,
            { role: "user", content: input.message },
          ],
        });
        const rawContent4 = response.choices[0]?.message?.content;
        const content = typeof rawContent4 === "string" ? rawContent4 : (rawContent4 as any[])?.[0]?.text || "";
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{ chatId: input.chatId, role: "user" as const, content: input.message }]);
            await db.insert(messages).values([{ chatId: input.chatId, role: "assistant" as const, content }]);
          }
        }
        return { content };
      }),

    // Artist Mode: image generation
    artist: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        prompt: z.string(),
        model: z.enum(["nano-banana-3", "tsunami-2"]).default("nano-banana-3"),
      }))
      .mutation(async ({ ctx, input }) => {
        const { url } = await generateImage({ prompt: input.prompt });
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{ chatId: input.chatId, role: "user" as const, content: input.prompt }]);
            await db.insert(messages).values([{
              chatId: input.chatId,
              role: "assistant" as const,
              content: `Generated image for: "${input.prompt}"`,
              fileUrl: url,
            }]);
          }
        }
        return { imageUrl: url, prompt: input.prompt };
      }),

    // Agent Mode: multiple AI agents in one conversation
    agent: protectedProcedure
      .input(z.object({
        chatId: z.number().optional(),
        message: z.string(),
        agentName: z.string(),
        agentPersonality: z.string().optional(),
        history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string(), agentName: z.string().optional() })).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const history = input.history || [];
        const personality = input.agentPersonality || `You are ${input.agentName}, a specialized AI agent inside Ayaax's Agent Mode.`;
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `${personality} You are part of a multi-agent conversation. Always identify yourself as ${input.agentName} in your responses. Be collaborative and build on what other agents have said when relevant.`,
            },
            ...history.map(h => ({ role: h.role, content: h.agentName ? `[${h.agentName}]: ${h.content}` : h.content })),
            { role: "user", content: input.message },
          ],
        });
        const rawContent5 = response.choices[0]?.message?.content;
        const content = typeof rawContent5 === "string" ? rawContent5 : (rawContent5 as any[])?.[0]?.text || "";
        if (input.chatId) {
          const db = await getDb();
          if (db) {
            await db.insert(messages).values([{
              chatId: input.chatId,
              role: "assistant" as const,
              content,
              agentName: input.agentName,
            }]);
          }
        }
        return { content, agentName: input.agentName };
      }),

    // Voice transcription
    transcribe: protectedProcedure
      .input(z.object({ audioUrl: z.string(), language: z.string().optional() }))
      .mutation(async ({ input }) => {
        const result = await transcribeAudio({ audioUrl: input.audioUrl, language: input.language });
        if ('error' in result) throw new Error(result.error);
        return { text: result.text, language: result.language || "en" };
      }),

    // Auto-generate chat title
    generateTitle: protectedProcedure
      .input(z.object({ message: z.string() }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "Generate a short, descriptive chat title (max 6 words) for the following user message. Return only the title, no quotes or extra text." },
            { role: "user", content: input.message },
          ],
        });
        const rawTitle = response.choices[0]?.message?.content;
        const titleStr = typeof rawTitle === "string" ? rawTitle.trim() : "New Chat";
        return { title: titleStr };
      }),
  }),

  subscription: router({
    getStatus: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { tier: "free" };
      const result = await db.select({ subscriptionTier: users.subscriptionTier })
        .from(users).where(eq(users.id, ctx.user.id)).limit(1);
      return { tier: result[0]?.subscriptionTier || "free" };
    }),

    upgrade: protectedProcedure
      .input(z.object({ plan: z.enum(["pro", "ultra"]) }))
      .mutation(async ({ input }) => {
        const urls = {
          ultra: "https://buy.stripe.com/eVq7sLg037Ss5qofEb7wA02",
          pro: "https://buy.stripe.com/3cIaEXaFJ4Gg5qo1Nl7wA01",
        };
        return { checkoutUrl: urls[input.plan] };
      }),
  }),
});

export type AppRouter = typeof appRouter;
