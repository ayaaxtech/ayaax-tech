import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock LLM and image generation
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: "Mocked AI response" } }],
  }),
}));

vi.mock("./_core/imageGeneration", () => ({
  generateImage: vi.fn().mockResolvedValue({ url: "https://example.com/image.png" }),
}));

vi.mock("./_core/voiceTranscription", () => ({
  transcribeAudio: vi.fn().mockResolvedValue({ text: "Hello world", language: "en" }),
}));

vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      subscriptionTier: "free",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("AI Routes", () => {
  it("beast mode returns content", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.beast({ message: "Build a todo app" });
    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });

  it("tsunami chat returns content", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.tsunami({ message: "Hello!" });
    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });

  it("deepgap mode returns content", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.deepgap({ message: "What is consciousness?" });
    expect(result).toHaveProperty("content");
  });

  it("analyst mode returns content", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.analyst({ message: "Research quantum computing" });
    expect(result).toHaveProperty("content");
  });

  it("artist mode returns imageUrl", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.artist({ prompt: "A sunset over mountains" });
    expect(result).toHaveProperty("imageUrl");
    expect(result.imageUrl).toBe("https://example.com/image.png");
  });

  it("agent mode returns content and agentName", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.agent({ message: "Hello", agentName: "Ayaax Alpha" });
    expect(result).toHaveProperty("content");
    expect(result.agentName).toBe("Ayaax Alpha");
  });

  it("generate title returns a title string", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.generateTitle({ message: "How do I build a React app?" });
    expect(result).toHaveProperty("title");
    expect(typeof result.title).toBe("string");
  });
});

describe("Subscription Routes", () => {
  it("getStatus returns tier", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.subscription.getStatus();
    expect(result).toHaveProperty("tier");
  });

  it("upgrade returns checkout URL for pro", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.subscription.upgrade({ plan: "pro" });
    expect(result.checkoutUrl).toContain("stripe.com");
    expect(result.checkoutUrl).toContain("3cIaEXaFJ4Gg5qo1Nl7wA01");
  });

  it("upgrade returns checkout URL for ultra", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.subscription.upgrade({ plan: "ultra" });
    expect(result.checkoutUrl).toContain("stripe.com");
    expect(result.checkoutUrl).toContain("eVq7sLg037Ss5qofEb7wA02");
  });
});

describe("Auth Routes", () => {
  it("logout clears cookie and returns success", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});
