import React, { createContext, useContext, useEffect, useState } from "react";
import { detectLanguage, getTranslation, Language, LANGUAGES, UIStrings } from "@/lib/translations";

type LanguageContextType = {
  language: string;
  setLanguage: (code: string) => void;
  t: UIStrings;
  dir: "ltr" | "rtl";
  currentLang: Language;
  autoDetect: () => void;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<string>(() => {
    return localStorage.getItem("ayaax-language") || "en";
  });

  const currentLang = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];
  const dir = currentLang.dir || "ltr";
  const t = getTranslation(language);

  const setLanguage = (code: string) => {
    setLanguageState(code);
    localStorage.setItem("ayaax-language", code);
  };

  const autoDetect = () => {
    const detected = detectLanguage();
    setLanguage(detected);
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = dir;
  }, [language, dir]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir, currentLang, autoDetect }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
