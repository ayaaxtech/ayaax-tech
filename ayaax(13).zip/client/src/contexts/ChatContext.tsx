import React, { createContext, useContext, useState } from "react";

export type AIMode = "beast" | "artist" | "tsunami" | "deepgap" | "analyst" | "agent";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  agentName?: string;
  fileUrl?: string;
  imageUrl?: string;
  sources?: { title: string; url: string }[];
  timestamp: number;
  isThinking?: boolean;
};

export type ChatSession = {
  id: string;
  title: string;
  mode: AIMode;
  messages: ChatMessage[];
  agents?: string[];
  isHidden?: boolean;
  createdAt: number;
  updatedAt: number;
};

type ChatContextType = {
  chats: ChatSession[];
  activeChat: ChatSession | null;
  activeChatId: string | null;
  mode: AIMode;
  setMode: (mode: AIMode) => void;
  createChat: (mode?: AIMode) => string;
  selectChat: (id: string) => void;
  deleteChat: (id: string) => void;
  hideChat: (id: string) => void;
  addMessage: (chatId: string, msg: Omit<ChatMessage, "id" | "timestamp">) => string;
  updateMessage: (chatId: string, msgId: string, updates: Partial<ChatMessage>) => void;
  updateChatTitle: (chatId: string, title: string) => void;
  addAgentToChat: (chatId: string, agentName: string) => void;
  removeAgentFromChat: (chatId: string, agentName: string) => void;
  updateChatMode: (chatId: string, newMode: AIMode) => void;
  isLoading: boolean;
  setIsLoading: (v: boolean) => void;
};

const ChatContext = createContext<ChatContextType | undefined>(undefined);

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [mode, setMode] = useState<AIMode>("tsunami");
  const [isLoading, setIsLoading] = useState(false);

  const activeChat = chats.find(c => c.id === activeChatId) || null;

  const createChat = (chatMode?: AIMode) => {
    const id = generateId();
    const newChat: ChatSession = {
      id,
      title: "New Chat",
      mode: chatMode || mode,
      messages: [],
      agents: chatMode === "agent" || mode === "agent" ? ["Ayaax Alpha", "Ayaax Beta"] : undefined,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setChats(prev => [newChat, ...prev]);
    setActiveChatId(id);
    return id;
  };

  const selectChat = (id: string) => setActiveChatId(id);

  const deleteChat = (id: string) => {
    setChats(prev => prev.filter(c => c.id !== id));
    if (activeChatId === id) {
      setActiveChatId(null);
    }
  };

  const hideChat = (id: string) => {
    setChats(prev => prev.map(c => c.id === id ? { ...c, isHidden: !c.isHidden } : c));
  };

  const addMessage = (chatId: string, msg: Omit<ChatMessage, "id" | "timestamp">) => {
    const msgId = generateId();
    setChats(prev => prev.map(c => {
      if (c.id !== chatId) return c;
      return {
        ...c,
        messages: [...c.messages, { ...msg, id: msgId, timestamp: Date.now() }],
        updatedAt: Date.now(),
      };
    }));
    return msgId;
  };

  const updateMessage = (chatId: string, msgId: string, updates: Partial<ChatMessage>) => {
    setChats(prev => prev.map(c => {
      if (c.id !== chatId) return c;
      return {
        ...c,
        messages: c.messages.map(m => m.id === msgId ? { ...m, ...updates } : m),
        updatedAt: Date.now(),
      };
    }));
  };

  const updateChatTitle = (chatId: string, title: string) => {
    setChats(prev => prev.map(c => c.id === chatId ? { ...c, title, updatedAt: Date.now() } : c));
  };

  const updateChatMode = (chatId: string, newMode: AIMode) => {
    setChats(prev => prev.map(c => c.id === chatId ? { ...c, mode: newMode, updatedAt: Date.now() } : c));
  };

  const addAgentToChat = (chatId: string, agentName: string) => {
    setChats(prev => prev.map(c => {
      if (c.id !== chatId) return c;
      const agents = c.agents || [];
      return { ...c, agents: [...agents, agentName] };
    }));
  };

  const canAddAgent = (userSubscription: string, currentAgentCount: number = 0): boolean => {
    if (userSubscription === "free") {
      return currentAgentCount < 3;
    }
    return true;
  };

  const removeAgentFromChat = (chatId: string, agentName: string) => {
    setChats(prev => prev.map(c => {
      if (c.id !== chatId) return c;
      return { ...c, agents: (c.agents || []).filter(a => a !== agentName) };
    }));
  };

  return (
    <ChatContext.Provider value={{
      chats, activeChat, activeChatId, mode, setMode,
      createChat, selectChat, deleteChat, hideChat,
      addMessage, updateMessage, updateChatTitle,
      addAgentToChat, removeAgentFromChat, updateChatMode,
      isLoading, setIsLoading,
      canAddAgent,
    } as any}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error("useChat must be used within ChatProvider");
  return ctx;
}
