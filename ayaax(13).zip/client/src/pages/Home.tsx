import { AyaaxLayout } from "@/components/AyaaxLayout";

export default function Home() {
  return <AyaaxLayout />;
}
