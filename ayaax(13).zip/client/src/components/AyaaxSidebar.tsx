import { useState } from "react";
import { useChat, ChatSession } from "@/contexts/ChatContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  X, Plus, Search, Settings, Zap, MessageSquare,
  Trash2, EyeOff, FileDown, MoreHorizontal, ChevronRight, LogIn, UserPlus, Crown
} from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663400365476/685TNE5MJKW3abUPJqSzv9/ayaax-logo_0f84bc55.png";

type Props = {
  open: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  onHideChat: (id: string) => void;
  onDownloadChat: () => void;
  onShowSettings: () => void;
  onShowUpgrade: () => void;
  activeChat: string | null;
};

function ChatItem({
  chat, isActive, onSelect, onDelete, onHide, onDownload
}: {
  chat: ChatSession;
  isActive: boolean;
  onSelect: () => void;
  onDelete: () => void;
  onHide: () => void;
  onDownload: () => void;
}) {
  const [showMenu, setShowMenu] = useState(false);
  const { t } = useLanguage();

  return (
    <div
      className={`group relative flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
        isActive ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
      }`}
      onClick={onSelect}
    >
      <MessageSquare size={14} className="flex-shrink-0" />
      <span className="flex-1 text-sm truncate">{chat.title}</span>
      <button
        onClick={e => { e.stopPropagation(); setShowMenu(!showMenu); }}
        className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-accent transition-all"
      >
        <MoreHorizontal size={14} />
      </button>
      {showMenu && (
        <div
          className="absolute right-0 top-full mt-1 z-50 bg-popover border border-border rounded-lg shadow-xl py-1 w-44"
          onMouseLeave={() => setShowMenu(false)}
        >
          <button
            onClick={e => { e.stopPropagation(); onDelete(); setShowMenu(false); }}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm text-destructive hover:bg-accent transition-colors"
          >
            <Trash2 size={13} /> {t.deleteChat}
          </button>
          <button
            onClick={e => { e.stopPropagation(); onHide(); setShowMenu(false); }}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <EyeOff size={13} /> {t.hideChat}
          </button>
          <button
            onClick={e => { e.stopPropagation(); onDownload(); setShowMenu(false); }}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <FileDown size={13} /> {t.downloadChat}
          </button>
        </div>
      )}
    </div>
  );
}

export function AyaaxSidebar({
  open, onClose, onNewChat, onSelectChat, onDeleteChat, onHideChat,
  onDownloadChat, onShowSettings, onShowUpgrade, activeChat
}: Props) {
  const { chats } = useChat();
  const { t } = useLanguage();
  const { isAuthenticated, user, logout } = useAuth();
  const [search, setSearch] = useState("");

  const visibleChats = chats.filter(c => !c.isHidden);
  const filtered = visibleChats.filter(c =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  const now = Date.now();
  const today = filtered.filter(c => now - c.updatedAt < 86400000);
  const yesterday = filtered.filter(c => now - c.updatedAt >= 86400000 && now - c.updatedAt < 172800000);
  const older = filtered.filter(c => now - c.updatedAt >= 172800000);

  if (!open) return null;

  return (
    <div
      className="flex flex-col h-full border-r border-border bg-sidebar text-sidebar-foreground"
      style={{ width: "260px", flexShrink: 0 }}
    >
      {/* Top row: logo + close */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <img src={LOGO_URL} alt="Ayaax" className="w-7 h-7 rounded-full" />
          <span className="font-bold text-foreground text-sm tracking-wide">Ayaax</span>
        </div>
        <button
          onClick={onClose}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          title="Close sidebar"
        >
          <X size={16} />
        </button>
      </div>

      {/* New chat button */}
      <div className="px-3 pt-3 pb-2">
        <button
          onClick={onNewChat}
          className="flex items-center gap-2 w-full px-3 py-2 rounded-lg bg-foreground text-background hover:opacity-90 transition-all text-sm font-medium"
        >
          <Plus size={16} />
          {t.newChat}
        </button>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div className="flex items-center gap-2 bg-input rounded-lg px-3 py-2">
          <Search size={13} className="text-muted-foreground flex-shrink-0" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={t.searchChats}
            className="flex-1 bg-transparent text-xs text-foreground placeholder:text-muted-foreground outline-none"
          />
        </div>
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto px-2">
        {today.length > 0 && (
          <div className="mb-2">
            <p className="text-xs text-muted-foreground px-2 py-1 font-medium">{t.today}</p>
            {today.map(c => (
              <ChatItem
                key={c.id}
                chat={c}
                isActive={c.id === activeChat}
                onSelect={() => onSelectChat(c.id)}
                onDelete={() => onDeleteChat(c.id)}
                onHide={() => onHideChat(c.id)}
                onDownload={onDownloadChat}
              />
            ))}
          </div>
        )}
        {yesterday.length > 0 && (
          <div className="mb-2">
            <p className="text-xs text-muted-foreground px-2 py-1 font-medium">{t.yesterday}</p>
            {yesterday.map(c => (
              <ChatItem
                key={c.id}
                chat={c}
                isActive={c.id === activeChat}
                onSelect={() => onSelectChat(c.id)}
                onDelete={() => onDeleteChat(c.id)}
                onHide={() => onHideChat(c.id)}
                onDownload={onDownloadChat}
              />
            ))}
          </div>
        )}
        {older.length > 0 && (
          <div className="mb-2">
            <p className="text-xs text-muted-foreground px-2 py-1 font-medium">{t.older}</p>
            {older.map(c => (
              <ChatItem
                key={c.id}
                chat={c}
                isActive={c.id === activeChat}
                onSelect={() => onSelectChat(c.id)}
                onDelete={() => onDeleteChat(c.id)}
                onHide={() => onHideChat(c.id)}
                onDownload={onDownloadChat}
              />
            ))}
          </div>
        )}
        {filtered.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-xs">
            {search ? "No chats found" : "No chats yet"}
          </div>
        )}
      </div>

      {/* Bottom section: auth + upgrade + settings */}
      <div className="border-t border-sidebar-border px-3 py-3 space-y-1">
        {!isAuthenticated ? (
          <>
            <a
              href={getLoginUrl()}
              className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            >
              <LogIn size={15} />
              {t.signIn}
            </a>
            <a
              href={getLoginUrl()}
              className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            >
              <UserPlus size={15} />
              {t.signUp}
            </a>
          </>
        ) : (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground">
            <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center text-xs font-bold text-foreground">
              {user?.name?.charAt(0) || "U"}
            </div>
            <span className="flex-1 truncate text-foreground text-xs">{user?.name || "User"}</span>
            <button
              onClick={() => logout()}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              {t.logout}
            </button>
          </div>
        )}

        <button
          onClick={onShowUpgrade}
          className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm font-medium text-amber-400 hover:bg-accent transition-colors"
        >
          <Crown size={15} />
          {t.upgrade}
        </button>

        <button
          onClick={onShowSettings}
          className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          <Settings size={15} />
          {t.settings}
        </button>
      </div>
    </div>
  );
}
