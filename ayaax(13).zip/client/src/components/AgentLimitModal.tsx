import React from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { getLoginUrl } from "@/const";
import { X, Lock } from "lucide-react";

type Props = {
  open: boolean;
  onClose: () => void;
  isAuthenticated: boolean;
};

export function AgentLimitModal({ open, onClose, isAuthenticated }: Props) {
  const { t } = useLanguage();

  if (!open) return null;

  const handleUpgrade = () => {
    window.location.href = "https://buy.stripe.com/eVq7sLg037Ss5qofEb7wA02";
  };

  const handleLogin = () => {
    window.location.href = getLoginUrl();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-2xl shadow-2xl max-w-sm w-full mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
              <Lock size={20} className="text-accent" />
            </div>
            <h2 className="text-lg font-bold text-foreground">Agent Limit Reached</h2>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <p className="text-sm text-muted-foreground mb-6">
          {isAuthenticated
            ? "Free plan allows up to 3 agents. Upgrade to add more agents and unlock unlimited features."
            : "Sign up or log in, then upgrade your plan to add more agents to your conversations."}
        </p>

        <div className="space-y-3">
          {!isAuthenticated && (
            <button
              onClick={handleLogin}
              className="w-full bg-secondary text-foreground py-2 rounded-lg font-medium hover:bg-accent transition-colors"
            >
              Sign In / Sign Up
            </button>
          )}
          <button
            onClick={handleUpgrade}
            className="w-full bg-accent text-accent-foreground py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
          >
            Upgrade to Ayaax Pro
          </button>
        </div>
      </div>
    </div>
  );
}
