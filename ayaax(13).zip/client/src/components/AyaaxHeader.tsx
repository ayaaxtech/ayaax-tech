import { useState, useRef, useEffect } from "react";
import { AIMode } from "@/contexts/ChatContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { LANGUAGES } from "@/lib/translations";
import { Menu, ChevronDown, Globe, Check, Zap, Palette, Waves, Brain, Search, Bot } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663400365476/685TNE5MJKW3abUPJqSzv9/ayaax-logo_0f84bc55.png";

type Props = {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  mode: AIMode;
  onModeChange: (mode: AIMode) => void;
  modeConfig: Record<AIMode, { label: string; icon: React.ReactNode; color: string; description: string }>;
};

function LanguageSelector() {
  const { language, setLanguage, currentLang, autoDetect, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = LANGUAGES.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.nativeName.toLowerCase().includes(search.toLowerCase()) ||
    l.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card hover:bg-accent transition-colors text-sm text-foreground"
      >
        <Globe size={14} className="text-muted-foreground" />
        <span className="max-w-[80px] truncate">{currentLang.nativeName}</span>
        <ChevronDown size={12} className={`text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute top-full mt-2 right-0 z-50 bg-popover border border-border rounded-xl shadow-2xl w-72 overflow-hidden">
          {/* Auto detect */}
          <div className="p-2 border-b border-border">
            <button
              onClick={() => { autoDetect(); setOpen(false); }}
              className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            >
              <Globe size={14} />
              {t.autoDetect}
            </button>
          </div>

          {/* Search */}
          <div className="p-2 border-b border-border">
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search language..."
              className="w-full bg-input rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none"
              autoFocus
            />
          </div>

          {/* Language list */}
          <div className="max-h-64 overflow-y-auto py-1">
            {filtered.map(lang => (
              <button
                key={lang.code}
                onClick={() => { setLanguage(lang.code); setOpen(false); setSearch(""); }}
                className="flex items-center justify-between w-full px-4 py-2 text-sm hover:bg-accent transition-colors"
              >
                <div className="flex flex-col items-start">
                  <span className="text-foreground">{lang.nativeName}</span>
                  <span className="text-xs text-muted-foreground">{lang.name}</span>
                </div>
                {language === lang.code && <Check size={14} className="text-foreground" />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ModeSelector({
  mode, onModeChange, modeConfig
}: {
  mode: AIMode;
  onModeChange: (mode: AIMode) => void;
  modeConfig: Record<AIMode, { label: string; icon: React.ReactNode; color: string; description: string }>;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const current = modeConfig[mode];

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-card hover:bg-accent transition-colors"
      >
        <span style={{ color: current.color }}>{current.icon}</span>
        <span className="text-sm font-medium text-foreground">{current.label}</span>
        <ChevronDown size={12} className={`text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute top-full mt-2 left-0 z-50 bg-popover border border-border rounded-xl shadow-2xl w-64 py-1 overflow-hidden">
          <p className="text-xs text-muted-foreground px-4 py-2 font-medium border-b border-border">{t.selectMode}</p>
          {(Object.entries(modeConfig) as [AIMode, typeof modeConfig[AIMode]][]).map(([key, cfg]) => (
            <button
              key={key}
              onClick={() => { onModeChange(key); setOpen(false); }}
              className={`flex items-start gap-3 w-full px-4 py-3 hover:bg-accent transition-colors text-left ${mode === key ? "bg-accent/50" : ""}`}
            >
              <span style={{ color: cfg.color }} className="mt-0.5">{cfg.icon}</span>
              <div>
                <p className="text-sm font-medium text-foreground">{cfg.label}</p>
                <p className="text-xs text-muted-foreground">{cfg.description}</p>
              </div>
              {mode === key && <Check size={14} className="text-foreground ml-auto mt-0.5" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function AyaaxHeader({ sidebarOpen, onToggleSidebar, mode, onModeChange, modeConfig }: Props) {
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-background/95 backdrop-blur-sm z-10">
      {/* Sidebar toggle */}
      {!sidebarOpen && (
        <button
          onClick={onToggleSidebar}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          <Menu size={18} />
        </button>
      )}

      {/* Logo (when sidebar closed) */}
      {!sidebarOpen && (
        <div className="flex items-center gap-2">
          <img src={LOGO_URL} alt="Ayaax" className="w-6 h-6 rounded-full" />
          <span className="font-bold text-foreground text-sm">Ayaax</span>
        </div>
      )}

      {/* Mode selector - centered */}
      <div className="flex-1 flex items-center justify-center">
        <ModeSelector mode={mode} onModeChange={onModeChange} modeConfig={modeConfig} />
      </div>

      {/* Language selector - right side */}
      <LanguageSelector />
    </div>
  );
}
