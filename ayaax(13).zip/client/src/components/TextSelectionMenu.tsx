import React, { useEffect, useState } from "react";
import { Copy, MessageCircle } from "lucide-react";
import { toast } from "sonner";

type Props = {
  onAskMore: (text: string) => void;
};

export function TextSelectionMenu({ onAskMore }: Props) {
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const [selectedText, setSelectedText] = useState("");

  useEffect(() => {
    const handleMouseUp = () => {
      const text = window.getSelection()?.toString() || "";
      if (text.length > 0) {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          const rect = range.getBoundingClientRect();
          setPosition({
            x: rect.left + rect.width / 2,
            y: rect.top - 10,
          });
          setSelectedText(text);
        }
      } else {
        setPosition(null);
        setSelectedText("");
      }
    };

    document.addEventListener("mouseup", handleMouseUp);
    return () => document.removeEventListener("mouseup", handleMouseUp);
  }, []);

  if (!position || !selectedText) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedText);
    toast.success("Copied to clipboard");
    setPosition(null);
    setSelectedText("");
  };

  const handleAskMore = () => {
    onAskMore(selectedText);
    setPosition(null);
    setSelectedText("");
  };

  return (
    <div
      className="fixed bg-card border border-border rounded-lg shadow-xl z-50 flex items-center gap-1 p-1"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        transform: "translate(-50%, -100%)",
      }}
    >
      <button
        onClick={handleCopy}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs text-foreground hover:bg-accent transition-colors"
        title="Copy selected text"
      >
        <Copy size={14} />
        Copy
      </button>
      <div className="w-px h-4 bg-border" />
      <button
        onClick={handleAskMore}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs text-foreground hover:bg-accent transition-colors"
        title="Ask more about this"
      >
        <MessageCircle size={14} />
        Ask more
      </button>
    </div>
  );
}
