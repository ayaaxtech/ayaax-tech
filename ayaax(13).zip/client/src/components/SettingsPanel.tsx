import { useTheme } from "@/contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { X, Sun, Moon, Type } from "lucide-react";
import { Slider } from "@/components/ui/slider";

type Props = {
  onClose: () => void;
  fontSize: number;
  onFontSizeChange: (size: number) => void;
};

export function SettingsPanel({ onClose, fontSize, onFontSizeChange }: Props) {
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-semibold text-foreground">{t.settings}</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="px-6 py-5 space-y-6">
          {/* Theme */}
          <div>
            <p className="text-sm font-medium text-foreground mb-3">Appearance</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => theme !== "dark" && toggleTheme?.()}
                className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl border transition-all ${
                  theme === "dark"
                    ? "border-foreground bg-accent text-foreground"
                    : "border-border text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
              >
                <Moon size={16} />
                <span className="text-sm font-medium">{t.darkMode}</span>
              </button>
              <button
                onClick={() => theme !== "light" && toggleTheme?.()}
                className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl border transition-all ${
                  theme === "light"
                    ? "border-foreground bg-accent text-foreground"
                    : "border-border text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
              >
                <Sun size={16} />
                <span className="text-sm font-medium">{t.lightMode}</span>
              </button>
            </div>
          </div>

          {/* Font size */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Type size={16} className="text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">{t.fontSize}</p>
              </div>
              <span className="text-sm text-muted-foreground">{fontSize}px</span>
            </div>
            <Slider
              value={[fontSize]}
              onValueChange={([v]) => onFontSizeChange(v)}
              min={12}
              max={20}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between mt-1">
              <span className="text-xs text-muted-foreground">Small</span>
              <span className="text-xs text-muted-foreground">Large</span>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-muted rounded-xl p-4">
            <p className="text-muted-foreground text-xs mb-1">Preview</p>
            <p className="text-foreground" style={{ fontSize: `${fontSize}px` }}>
              The quick brown fox jumps over the lazy dog.
            </p>
          </div>
        </div>

        <div className="px-6 pb-5">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-foreground text-background rounded-xl text-sm font-medium hover:opacity-90 transition-opacity"
          >
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );
}
