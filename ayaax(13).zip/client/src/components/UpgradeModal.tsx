import { useLanguage } from "@/contexts/LanguageContext";
import { X, Crown, Zap, Check } from "lucide-react";

type Props = {
  onClose: () => void;
};

const PLANS = [
  {
    id: "pro",
    name: "Ayaax Pro",
    price: "$12",
    period: "/month",
    color: "oklch(0.65 0.18 220)",
    stripeUrl: "https://buy.stripe.com/3cIaEXaFJ4Gg5qo1Nl7wA01",
    features: [
      "Unlimited chats",
      "All AI modes",
      "Up to 10 agents in Agent Mode",
      "Priority response speed",
      "File uploads up to 25MB",
      "Advanced image generation",
    ],
  },
  {
    id: "ultra",
    name: "Ayaax Ultra",
    price: "$29",
    period: "/month",
    color: "oklch(0.75 0.22 60)",
    stripeUrl: "https://buy.stripe.com/eVq7sLg037Ss5qofEb7wA02",
    popular: true,
    features: [
      "Everything in Pro",
      "Unlimited agents in Agent Mode",
      "Beast Mode: full app generation",
      "Nano Banana 3 image generation",
      "Deep research with 50+ sources",
      "API access",
      "Priority support",
    ],
  },
];

export function UpgradeModal({ onClose }: Props) {
  const { t } = useLanguage();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border">
          <div>
            <h2 className="font-bold text-xl text-foreground flex items-center gap-2">
              <Crown size={20} className="text-amber-400" />
              {t.upgrade} Ayaax
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">Unlock the full power of AI</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {PLANS.map(plan => (
              <div
                key={plan.id}
                className={`relative rounded-2xl border p-5 flex flex-col gap-4 ${
                  plan.popular
                    ? "border-amber-400/50 bg-amber-400/5"
                    : "border-border bg-background"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="bg-amber-400 text-black text-xs font-bold px-3 py-1 rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Zap size={16} style={{ color: plan.color }} />
                    <h3 className="font-bold text-foreground">{plan.name}</h3>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground text-sm">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-2 flex-1">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                      <Check size={14} className="mt-0.5 flex-shrink-0" style={{ color: plan.color }} />
                      {f}
                    </li>
                  ))}
                </ul>

                <a
                  href={plan.stripeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-3 rounded-xl text-center text-sm font-semibold transition-all hover:opacity-90"
                  style={{
                    background: plan.popular ? "oklch(0.75 0.22 60)" : "var(--foreground)",
                    color: plan.popular ? "black" : "var(--background)",
                  }}
                >
                  Get {plan.name}
                </a>
              </div>
            ))}
          </div>

          {/* Free plan note */}
          <div className="mt-4 text-center">
            <p className="text-xs text-muted-foreground">
              Free plan includes 3 agents in Agent Mode, basic chat, and standard image generation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
