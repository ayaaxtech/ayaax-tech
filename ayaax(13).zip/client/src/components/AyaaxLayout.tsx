import { useState, useRef, useEffect, useCallback } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useChat, AIMode, ChatMessage } from "@/contexts/ChatContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { AyaaxSidebar } from "./AyaaxSidebar";
import { AyaaxHeader } from "./AyaaxHeader";
import { VoiceInterface } from "./VoiceInterface";
import { SettingsPanel } from "./SettingsPanel";
import { UpgradeModal } from "./UpgradeModal";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Send, Plus, Mic, ChevronDown, Copy, Download, RefreshCw,
  Trash2, EyeOff, FileDown, Zap, Palette, Waves, Brain, Search, Bot, Loader2
} from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663400365476/685TNE5MJKW3abUPJqSzv9/ayaax-logo_0f84bc55.png";

const MODE_CONFIG: Record<AIMode, { label: string; icon: React.ReactNode; color: string; description: string }> = {
  beast: { label: "Beast Mode", icon: <Zap size={14} />, color: "oklch(0.65 0.22 30)", description: "Full app & advanced code generation" },
  artist: { label: "Artist Mode", icon: <Palette size={14} />, color: "oklch(0.65 0.22 290)", description: "AI image generation" },
  tsunami: { label: "Tsunami 2.0", icon: <Waves size={14} />, color: "oklch(0.65 0.18 220)", description: "Everyday conversational AI" },
  deepgap: { label: "Deep-Gap", icon: <Brain size={14} />, color: "oklch(0.65 0.18 160)", description: "Visible thinking before responding" },
  analyst: { label: "Analyst", icon: <Search size={14} />, color: "oklch(0.65 0.18 60)", description: "Research with clickable sources" },
  agent: { label: "Agent Mode", icon: <Bot size={14} />, color: "oklch(0.65 0.18 330)", description: "Multiple AI agents in one chat" },
};

function ThinkingBlock({ content }: { content: string }) {
  const thinkMatch = content.match(/<thinking>([\s\S]*?)<\/thinking>/);
  const thinkContent = thinkMatch?.[1] || "";
  const mainContent = content.replace(/<thinking>[\s\S]*?<\/thinking>/, "").trim();
  const [expanded, setExpanded] = useState(false);

  return (
    <div>
      {thinkContent && (
        <div className="mb-3">
          <button
            onClick={() => setExpanded(v => !v)}
            className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors mb-1"
          >
            <Brain size={12} />
            <span>{expanded ? "Hide" : "Show"} thinking process</span>
            <ChevronDown size={12} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
          </button>
          {expanded && (
            <div className="bg-muted/50 border border-border rounded-lg p-3 text-xs text-muted-foreground font-mono whitespace-pre-wrap">
              {thinkContent}
            </div>
          )}
        </div>
      )}
      <Streamdown className="prose-ayaax">{mainContent || content}</Streamdown>
    </div>
  );
}

function MessageBubble({
  msg, chatId, onRetry
}: {
  msg: ChatMessage;
  chatId: string;
  onRetry: (content: string) => void;
}) {
  const { t } = useLanguage();
  const isUser = msg.role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(msg.content);
    toast.success("Copied to clipboard");
  };

  const handleDownload = () => {
    const blob = new Blob([msg.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ayaax-response-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isUser) {
    return (
      <div className="flex justify-end mb-4">
        <div className="max-w-[75%] bg-secondary rounded-2xl rounded-tr-sm px-4 py-3 text-foreground text-sm">
          {msg.fileUrl && msg.fileUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i) && (
            <img src={msg.fileUrl} alt="uploaded" className="max-w-full rounded-lg mb-2" />
          )}
          <p className="whitespace-pre-wrap">{msg.content}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3 mb-6 group">
      <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 mt-1">
        {msg.agentName ? (
          <div className="w-full h-full flex items-center justify-center bg-accent text-xs font-bold text-foreground">
            {msg.agentName.charAt(0)}
          </div>
        ) : (
          <img src={LOGO_URL} alt="Ayaax" className="w-full h-full object-cover" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        {msg.agentName && (
          <p className="text-xs font-semibold text-muted-foreground mb-1">{msg.agentName}</p>
        )}
        {msg.isThinking ? (
          <div className="flex items-center gap-1.5 py-2">
            <div className="thinking-dot w-2 h-2 rounded-full bg-muted-foreground" />
            <div className="thinking-dot w-2 h-2 rounded-full bg-muted-foreground" />
            <div className="thinking-dot w-2 h-2 rounded-full bg-muted-foreground" />
          </div>
        ) : (
          <>
            {msg.imageUrl ? (
              <div>
                <img src={msg.imageUrl} alt="Generated" className="max-w-sm rounded-xl border border-border" />
                <p className="text-xs text-muted-foreground mt-2">{msg.content}</p>
              </div>
            ) : (
              <div className="text-sm text-foreground">
                <ThinkingBlock content={msg.content} />
              </div>
            )}
            <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-accent transition-colors"
              >
                <Copy size={12} /> {t.copy}
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-accent transition-colors"
              >
                <Download size={12} /> {t.download}
              </button>
              <button
                onClick={() => onRetry(msg.content)}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-accent transition-colors"
              >
                <RefreshCw size={12} /> {t.retry}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function WelcomeScreen({ onModeSelect }: { onModeSelect: (mode: AIMode) => void }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-12">
      <img src={LOGO_URL} alt="Ayaax" className="w-20 h-20 rounded-full mb-6 shadow-2xl" />
      <h1 className="text-3xl font-bold text-foreground mb-2">{t.welcomeTitle}</h1>
      <p className="text-muted-foreground text-center mb-10 max-w-md">{t.welcomeSubtitle}</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full max-w-2xl">
        {(Object.entries(MODE_CONFIG) as [AIMode, typeof MODE_CONFIG[AIMode]][]).map(([key, cfg]) => (
          <button
            key={key}
            onClick={() => onModeSelect(key)}
            className="flex flex-col items-start gap-2 p-4 rounded-xl border border-border bg-card hover:bg-accent transition-all hover:border-foreground/20 text-left group"
          >
            <div className="flex items-center gap-2">
              <span style={{ color: cfg.color }}>{cfg.icon}</span>
              <span className="text-sm font-semibold text-foreground">{cfg.label}</span>
            </div>
            <p className="text-xs text-muted-foreground">{cfg.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

export function AyaaxLayout() {
  const { theme } = useTheme();
  const { t, language } = useLanguage();
  const {
    chats, activeChat, activeChatId, mode, setMode,
    createChat, selectChat, deleteChat, hideChat,
    addMessage, updateMessage, updateChatTitle, isLoading, setIsLoading,
    addAgentToChat, updateChatMode,
  } = useChat();
  const { isAuthenticated } = useAuth();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [input, setInput] = useState("");
  const [showVoice, setShowVoice] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [artistModel, setArtistModel] = useState<"nano-banana-3" | "tsunami-2">("nano-banana-3");
  const [agentNames] = useState(["Ayaax Alpha", "Ayaax Beta", "Ayaax Gamma"]);
  const [fontSize, setFontSize] = useState(14);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const beastMutation = trpc.ai.beast.useMutation();
  const tsunamiMutation = trpc.ai.tsunami.useMutation();
  const deepgapMutation = trpc.ai.deepgap.useMutation();
  const analystMutation = trpc.ai.analyst.useMutation();
  const artistMutation = trpc.ai.artist.useMutation();
  const agentMutation = trpc.ai.agent.useMutation();
  const generateTitleMutation = trpc.ai.generateTitle.useMutation();

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [activeChat?.messages, scrollToBottom]);

  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShowScrollBtn(scrollHeight - scrollTop - clientHeight > 100);
    };
    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    const userInput = input.trim();
    setInput("");

    let chatId = activeChatId;
    if (!chatId) {
      // Create a new chat without specifying mode - keep it flexible
      chatId = createChat();
    }

    // Add user message
    addMessage(chatId, { role: "user", content: userInput });

    // Auto-generate title for first message
    if (!activeChat || activeChat.messages.length === 0) {
      generateTitleMutation.mutate({ message: userInput }, {
        onSuccess: (data) => updateChatTitle(chatId!, data.title),
      });
    }

    // Update chat's mode to current mode (allows mode switching within same chat)
    if (activeChat && activeChat.mode !== mode) {
      updateChatMode(chatId, mode);
    }

    // Add thinking placeholder
    const thinkingId = addMessage(chatId, { role: "assistant", content: "", isThinking: true });

    setIsLoading(true);

    try {
      const history = (activeChat?.messages || [])
        .filter(m => !m.isThinking)
        .slice(-10)
        .map(m => ({ role: m.role as "user" | "assistant", content: m.content }));

      if (mode === "beast") {
        const res = await beastMutation.mutateAsync({ message: userInput, history });
        updateMessage(chatId, thinkingId, { content: res.content, isThinking: false });
      } else if (mode === "tsunami") {
        const res = await tsunamiMutation.mutateAsync({ message: userInput, history });
        updateMessage(chatId, thinkingId, { content: res.content, isThinking: false });
      } else if (mode === "deepgap") {
        // Show thinking animation for a moment
        await new Promise(r => setTimeout(r, 1500));
        const res = await deepgapMutation.mutateAsync({ message: userInput, history });
        updateMessage(chatId, thinkingId, { content: res.content, isThinking: false });
      } else if (mode === "analyst") {
        const res = await analystMutation.mutateAsync({ message: userInput, history });
        updateMessage(chatId, thinkingId, { content: res.content, isThinking: false });
      } else if (mode === "artist") {
        const res = await artistMutation.mutateAsync({ prompt: userInput, model: artistModel });
        updateMessage(chatId, thinkingId, {
          content: `Generated image for: "${userInput}"`,
          imageUrl: res.imageUrl,
          isThinking: false,
        });
      } else if (mode === "agent") {
        const agents = activeChat?.agents || agentNames.slice(0, 2);
        updateMessage(chatId, thinkingId, { content: "", isThinking: false });
        for (const agentName of agents) {
          const agentThinkId = addMessage(chatId, { role: "assistant", content: "", agentName, isThinking: true });
          const agentHistory = (activeChat?.messages || [])
            .filter(m => !m.isThinking)
            .slice(-6)
            .map(m => ({ role: m.role as "user" | "assistant", content: m.content, agentName: m.agentName }));
          const res = await agentMutation.mutateAsync({ message: userInput, agentName, history: agentHistory });
          updateMessage(chatId, agentThinkId, { content: res.content, isThinking: false });
          await new Promise(r => setTimeout(r, 300));
        }
      }
    } catch (err: any) {
      updateMessage(chatId, thinkingId, {
        content: `Sorry, something went wrong. Please try again.\n\n*Error: ${err?.message || "Unknown error"}*`,
        isThinking: false,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    toast.info(`File "${file.name}" selected. File upload coming soon.`);
  };

  const handleRetry = (content: string) => {
    setInput(content);
    textareaRef.current?.focus();
  };

  const handleDownloadChat = () => {
    if (!activeChat) return;
    const text = activeChat.messages
      .filter(m => !m.isThinking)
      .map(m => `[${m.role.toUpperCase()}${m.agentName ? ` - ${m.agentName}` : ""}]\n${m.content}`)
      .join("\n\n---\n\n");
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeChat.title}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleVoiceResult = (text: string) => {
    setInput(prev => prev + (prev ? " " : "") + text);
    setShowVoice(false);
  };

  const currentMessages = activeChat?.messages || [];

  return (
    <div
      className={`flex h-screen overflow-hidden bg-background text-foreground ${theme === "light" ? "light" : "dark"}`}
      style={{ fontSize: `${fontSize}px` }}
    >
      {/* Sidebar */}
      <AyaaxSidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onNewChat={() => createChat()}
        onSelectChat={selectChat}
        onDeleteChat={deleteChat}
        onHideChat={hideChat}
        onDownloadChat={handleDownloadChat}
        onShowSettings={() => setShowSettings(true)}
        onShowUpgrade={() => setShowUpgrade(true)}
        activeChat={activeChatId}
      />

      {/* Main area */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Header */}
        <AyaaxHeader
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          mode={mode}
          onModeChange={setMode}
          modeConfig={MODE_CONFIG}
        />

        {/* Chat area */}
        <div
          ref={messagesContainerRef}
          className="flex-1 overflow-y-auto px-4 py-6 relative"
        >
          {currentMessages.length === 0 ? (
            <WelcomeScreen onModeSelect={(m) => { setMode(m); }} />
          ) : (
            <div className="max-w-3xl mx-auto">
              {currentMessages.map(msg => (
                <MessageBubble
                  key={msg.id}
                  msg={msg}
                  chatId={activeChatId || ""}
                  onRetry={handleRetry}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Scroll to bottom button */}
          {showScrollBtn && (
            <button
              onClick={scrollToBottom}
              className="fixed bottom-28 right-6 w-9 h-9 rounded-full bg-secondary border border-border flex items-center justify-center shadow-lg hover:bg-accent transition-colors z-10"
              title={t.scrollToBottom}
            >
              <ChevronDown size={16} />
            </button>
          )}
        </div>

        {/* Chat controls bar (above input) */}
        {activeChat && (
          <div className="flex items-center gap-2 px-4 py-1 border-t border-border/50">
            <span className="text-xs text-muted-foreground flex-1 truncate">{activeChat.title}</span>
            <button
              onClick={() => deleteChat(activeChat.id)}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive px-2 py-1 rounded hover:bg-accent transition-colors"
              title={t.deleteChat}
            >
              <Trash2 size={12} />
            </button>
            <button
              onClick={() => hideChat(activeChat.id)}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-accent transition-colors"
              title={t.hideChat}
            >
              <EyeOff size={12} />
            </button>
            <button
              onClick={handleDownloadChat}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-accent transition-colors"
              title={t.downloadChat}
            >
              <FileDown size={12} />
            </button>
          </div>
        )}

        {/* Agent mode: add agents */}
        {mode === "agent" && activeChat && (
          <div className="flex items-center gap-2 px-4 py-2 border-t border-border/50 bg-card/50">
            <Bot size={14} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Agents:</span>
            {(activeChat.agents || []).map(name => (
              <span key={name} className="text-xs bg-accent px-2 py-0.5 rounded-full text-foreground">{name}</span>
            ))}
            <button
              onClick={() => {
                if ((activeChat.agents || []).length >= 3 && !isAuthenticated) {
                  setShowUpgrade(true);
                  return;
                }
                const newName = `Ayaax ${String.fromCharCode(65 + (activeChat.agents?.length || 0))}`;
                addAgentToChat(activeChat.id, newName);
              }}
              className="text-xs text-muted-foreground hover:text-foreground px-2 py-0.5 rounded border border-border hover:bg-accent transition-colors"
            >
              + {t.addAgent}
            </button>
          </div>
        )}

        {/* Input area */}
        <div className="border-t border-border bg-background px-4 py-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-end gap-2 bg-card border border-border rounded-2xl px-3 py-2 focus-within:border-foreground/30 transition-colors">
              {/* File upload button */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors mb-0.5"
                title={t.uploadFile}
              >
                <Plus size={18} />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleFileUpload}
                accept="image/*,.pdf,.txt,.md,.js,.ts,.py,.json"
              />

              {/* Text input */}
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t.typeMessage}
                className="flex-1 min-h-[40px] max-h-[200px] resize-none border-0 bg-transparent p-0 focus-visible:ring-0 text-foreground placeholder:text-muted-foreground text-sm"
                rows={1}
              />

              {/* Mic button */}
              <button
                onClick={() => setShowVoice(true)}
                className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors mb-0.5"
                title={t.voiceInput}
              >
                <Mic size={18} />
              </button>

              {/* Send button */}
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center bg-foreground text-background hover:opacity-90 disabled:opacity-40 transition-all mb-0.5"
                title={t.sendMessage}
              >
                {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </div>

            {/* Mode indicator */}
            <div className="flex items-center justify-center mt-2">
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <span style={{ color: MODE_CONFIG[mode].color }}>{MODE_CONFIG[mode].icon}</span>
                {MODE_CONFIG[mode].label}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Voice Interface */}
      {showVoice && (
        <VoiceInterface
          onClose={() => setShowVoice(false)}
          onResult={handleVoiceResult}
        />
      )}

      {/* Settings Panel */}
      {showSettings && (
        <SettingsPanel
          onClose={() => setShowSettings(false)}
          fontSize={fontSize}
          onFontSizeChange={setFontSize}
        />
      )}

      {/* Upgrade Modal */}
      {showUpgrade && (
        <UpgradeModal onClose={() => setShowUpgrade(false)} />
      )}
    </div>
  );
}
