import { useState, useEffect, useRef, useCallback } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { X, Mic, Square } from "lucide-react";

type Props = {
  onClose: () => void;
  onResult: (text: string) => void;
};

export function VoiceInterface({ onClose, onResult }: Props) {
  const { t } = useLanguage();
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [audioLevels, setAudioLevels] = useState<number[]>(Array(9).fill(0.3));
  const [status, setStatus] = useState<"idle" | "recording" | "processing">("idle");

  const recognitionRef = useRef<any>(null);
  const animFrameRef = useRef<number | undefined>(undefined);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const animateLevels = useCallback(() => {
    if (analyserRef.current) {
      const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
      analyserRef.current.getByteFrequencyData(dataArray);
      const step = Math.floor(dataArray.length / 9);
      const levels = Array.from({ length: 9 }, (_, i) => {
        const val = dataArray[i * step] || 0;
        return Math.max(0.15, val / 255);
      });
      setAudioLevels(levels);
    } else if (isRecording) {
      setAudioLevels(prev => prev.map(() => 0.2 + Math.random() * 0.8));
    }
    animFrameRef.current = requestAnimationFrame(animateLevels);
  }, [isRecording]);

  const startRecording = async () => {
    setIsRecording(true);
    setStatus("recording");
    setTranscript("");

    // Try Web Speech API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = navigator.language || "en-US";
      recognition.onresult = (e: any) => {
        let interim = "";
        let final = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (e.results[i].isFinal) final += e.results[i][0].transcript;
          else interim += e.results[i][0].transcript;
        }
        setTranscript(final || interim);
      };
      recognition.onerror = () => setStatus("idle");
      recognition.start();
      recognitionRef.current = recognition;
    }

    // Audio visualizer
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;
    } catch {
      // No mic access, use simulated levels
    }

    animFrameRef.current = requestAnimationFrame(animateLevels);
  };

  const stopRecording = () => {
    setIsRecording(false);
    setStatus("idle");
    recognitionRef.current?.stop();
    streamRef.current?.getTracks().forEach(t => t.stop());
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    setAudioLevels(Array(9).fill(0.3));
    if (transcript) {
      onResult(transcript);
    }
  };

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
      streamRef.current?.getTracks().forEach(t => t.stop());
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background/95 backdrop-blur-md">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-6 right-6 w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
      >
        <X size={20} />
      </button>

      {/* Sound waves */}
      <div className="flex items-center justify-center gap-1.5 mb-12 h-16">
        {audioLevels.map((level, i) => (
          <div
            key={i}
            className="sound-bar w-1.5 rounded-full bg-foreground transition-all duration-75"
            style={{
              height: `${level * 60}px`,
              opacity: isRecording ? 0.8 + level * 0.2 : 0.3,
              animationPlayState: isRecording ? "running" : "paused",
            }}
          />
        ))}
      </div>

      {/* Microphone button */}
      <button
        onClick={isRecording ? stopRecording : startRecording}
        className={`w-24 h-24 rounded-full flex items-center justify-center transition-all ${
          isRecording
            ? "bg-red-500 hover:bg-red-600 mic-pulse"
            : "bg-foreground hover:opacity-90"
        }`}
      >
        {isRecording ? (
          <Square size={32} className="text-white" />
        ) : (
          <Mic size={36} className="text-background" />
        )}
      </button>

      {/* Status text */}
      <p className="mt-6 text-sm font-medium text-foreground">
        {isRecording ? t.listening : t.voiceInput}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        {isRecording ? t.stopRecording : "Tap to start speaking"}
      </p>

      {/* Transcript preview */}
      {transcript && (
        <div className="mt-8 max-w-md w-full mx-4 bg-card border border-border rounded-xl p-4">
          <p className="text-sm text-foreground text-center">{transcript}</p>
        </div>
      )}

      {/* Use transcript button */}
      {transcript && !isRecording && (
        <button
          onClick={() => onResult(transcript)}
          className="mt-4 px-6 py-2 bg-foreground text-background rounded-full text-sm font-medium hover:opacity-90 transition-opacity"
        >
          Use this text
        </button>
      )}
    </div>
  );
}
