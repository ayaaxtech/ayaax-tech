# Ayaax AI Platform - TODO

## Core Layout & UI
- [x] Collapsible sidebar with close button on top row
- [x] Sign Up / Sign In buttons in bottom-left corner
- [x] Upgrade button in bottom-left corner
- [x] Dark/light mode theme switcher
- [x] Font size adjustment in settings
- [x] Official logo in header and branding elements
- [x] Scroll-to-bottom arrow button
- [x] Language selector (50+ languages) in top middle row with auto-detect

## AI Modes
- [x] Beast Mode - full app and advanced code generation
- [x] Artist Mode - image generation (Nano Banana 3 / Tsunami 2.0)
- [x] Tsunami 2.0 Chat - everyday conversational AI
- [x] Deep-Gap Mode - visible thinking pause before responding
- [x] Analyst Mode - research with clickable website links
- [x] Agent Mode - multiple AI bots in one conversation + separate chats

## Voice & File Features
- [x] Plus-shaped file upload button
- [x] Microphone button with full-screen voice interface
- [x] Animated microphone with sound wave visualization
- [x] Live speech-to-text transcription

## Chat Controls
- [x] Copy, download, retry buttons under each AI response
- [x] Delete, hide, download chat management controls
- [x] Chat history sidebar

## Subscription & Auth
- [x] Free plan: up to 3 additional AIs in Agent Mode
- [x] Stripe upgrade system (Ayaax Ultra + Ayaax Pro)
- [x] Ayaax Ultra: https://buy.stripe.com/eVq7sLg037Ss5qofEb7wA02
- [x] Ayaax Pro: https://buy.stripe.com/3cIaEXaFJ4Gg5qo1Nl7wA01
- [x] Sign up / Sign in flow

## Database Schema
- [x] Users table (extended with subscription tier)
- [x] Chats table
- [x] Messages table
- [x] AI agents table (for Agent Mode)

## Multilingual Support
- [x] 50+ language options
- [x] Auto-detect language button
- [x] Full UI translation when language is selected

## Showcase Webpage
- [x] Interactive feature overview page
- [x] Charts and visualizations
- [x] Mode showcase cards

## Bug Fixes
- [x] Mode switching should not create new chats - keep conversation in one chat thread

## Additional Fixes
- [x] Fix all language translations to work correctly (60+ languages now complete)
- [x] Fix mode selection from welcome screen to not create new chats

## New Features (Current Sprint)
- [ ] Free plan: limit Agent Mode to 3 agents max
- [ ] Show upgrade prompt when free user tries to add 4th agent
- [ ] Text selection context menu with "Copy" and "Ask more about this" options
